import { Injectable } from '@angular/core';
import { AlertController } from 'ionic-angular';
import { ToastController } from 'ionic-angular';
import { GroceriesServiceProvider } from '../../providers/groceries-service/groceries-service';

/*
  Generated class for the InputDialogServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class InputDialogServiceProvider {

  constructor(public alertCtrl: AlertController, public toastCtrl: ToastController, public dataService: GroceriesServiceProvider) {
    //console.log('Hello InputDialogServiceProvider Provider');
  }

  showPrompt(item?, index?) {
    const prompt = this.alertCtrl.create({
      title: item ? 'Edit Item' : 'Add Item',
      message: item ? 'Edit Item Details' : 'New Items Details',
      inputs: [
        {
          name: "name",
          type: "text",
          placeholder: "Item Name",
          value: item ? item.name : null
        },
        {
          name: "quantity",
          type: "number",
          placeholder: "Quantity",
          value: item ? item.quantity : null
        }
      ],
      buttons: [
        {
          text: "Cancel",
          handler: () => {

          }
        },
        {
          text: item ? "Update": "Add",
          handler: item => {
            if (index != undefined) {
              this.dataService.editItem(item, index);
              const toast = this.toastCtrl.create({
                message: item.name + " Updated",
                duration: 3000,
                showCloseButton: true
              });
              toast.present();
            }
            else {
              this.dataService.addItem(item);
              const toast = this.toastCtrl.create({
                message:  "Item Added",
                duration: 3000,
                showCloseButton: true
              });
              toast.present();
            }
          }
        }
      ]
    })
    prompt.present();
  }
}
